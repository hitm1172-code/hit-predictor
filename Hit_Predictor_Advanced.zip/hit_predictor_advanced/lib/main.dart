
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const bg = Color(0xFF070B10);
const card = Color(0xFF0E151D);
const accent = Color(0xFF19D3AE);

void main() => runApp(const HitPredictor());

class HitPredictor extends StatelessWidget {
  const HitPredictor({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Hit Predictor',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: ColorScheme.fromSeed(
          seedColor: accent,
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class ApiFootball {
  static const base = 'https://v3.football.api-sports.io';

  // NEVER put a real key directly in source control.
  // Start the app with:
  // flutter run --dart-define=API_KEY=YOUR_KEY
  static const apiKey = String.fromEnvironment('API_KEY');

  Future<Map<String, dynamic>> get(
    String endpoint,
    Map<String, String> params,
  ) async {
    if (apiKey.isEmpty) {
      throw Exception(
        'API key missing. Run with --dart-define=API_KEY=YOUR_KEY',
      );
    }

    final uri = Uri.parse('$base/$endpoint').replace(queryParameters: params);
    final response = await http.get(
      uri,
      headers: {'x-apisports-key': apiKey},
    );

    if (response.statusCode != 200) {
      throw Exception('API error: ${response.statusCode}');
    }

    final data = jsonDecode(response.body) as Map<String, dynamic>;
    if ((data['errors'] as Map?)?.isNotEmpty == true) {
      throw Exception(data['errors'].toString());
    }
    return data;
  }

  Future<List<Fixture>> todayFixtures() async {
    final now = DateTime.now();
    final date =
        '${now.year.toString().padLeft(4, '0')}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';

    final data = await get('fixtures', {'date': date});
    final rows = (data['response'] as List? ?? []);

    return rows.map((e) => Fixture.fromJson(e)).toList();
  }

  Future<Prediction?> prediction(int fixtureId) async {
    final data = await get(
      'predictions',
      {'fixture': fixtureId.toString()},
    );
    final rows = (data['response'] as List? ?? []);
    if (rows.isEmpty) return null;
    return Prediction.fromJson(rows.first);
  }
}

class Fixture {
  final int id;
  final String league;
  final String home;
  final String away;
  final String date;
  final String status;

  Fixture({
    required this.id,
    required this.league,
    required this.home,
    required this.away,
    required this.date,
    required this.status,
  });

  factory Fixture.fromJson(Map<String, dynamic> j) {
    final f = j['fixture'] ?? {};
    final teams = j['teams'] ?? {};
    final league = j['league'] ?? {};
    return Fixture(
      id: (f['id'] ?? 0) as int,
      league: (league['name'] ?? 'Unknown') as String,
      home: (teams['home']?['name'] ?? 'Home') as String,
      away: (teams['away']?['name'] ?? 'Away') as String,
      date: (f['date'] ?? '') as String,
      status: (f['status']?['short'] ?? '') as String,
    );
  }
}

class Prediction {
  final String winner;
  final String advice;
  final String homeWin;
  final String draw;
  final String awayWin;

  Prediction({
    required this.winner,
    required this.advice,
    required this.homeWin,
    required this.draw,
    required this.awayWin,
  });

  factory Prediction.fromJson(Map<String, dynamic> j) {
    final p = j['predictions'] ?? {};
    final percent = p['percent'] ?? {};
    return Prediction(
      winner: p['winner']?['name'] ?? 'No prediction',
      advice: p['advice'] ?? 'No advice',
      homeWin: percent['home'] ?? '-',
      draw: percent['draw'] ?? '-',
      awayWin: percent['away'] ?? '-',
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final api = ApiFootball();
  late Future<List<Fixture>> future;
  int tab = 0;

  @override
  void initState() {
    super.initState();
    future = api.todayFixtures();
  }

  void refresh() {
    setState(() => future = api.todayFixtures());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: tab == 0
            ? PredictionsPage(api: api, future: future, onRefresh: refresh)
            : tab == 1
                ? const ResultsPage()
                : const ProfilePage(),
      ),
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF0B1118),
        selectedIndex: tab,
        indicatorColor: const Color(0xFF123B36),
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.sports_soccer_outlined),
            selectedIcon: Icon(Icons.sports_soccer),
            label: 'Matches',
          ),
          NavigationDestination(
            icon: Icon(Icons.history),
            label: 'Results',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}

class PredictionsPage extends StatelessWidget {
  final ApiFootball api;
  final Future<List<Fixture>> future;
  final VoidCallback onRefresh;

  const PredictionsPage({
    super.key,
    required this.api,
    required this.future,
    required this.onRefresh,
  });

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: () async => onRefresh(),
      child: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(child: _header()),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    "Today's Matches",
                    style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900),
                  ),
                  IconButton(
                    onPressed: onRefresh,
                    icon: const Icon(Icons.refresh),
                  ),
                ],
              ),
            ),
          ),
          FutureBuilder<List<Fixture>>(
            future: future,
            builder: (context, snap) {
              if (snap.connectionState == ConnectionState.waiting) {
                return const SliverFillRemaining(
                  child: Center(child: CircularProgressIndicator()),
                );
              }

              if (snap.hasError) {
                return SliverToBoxAdapter(
                  child: _errorCard(snap.error.toString()),
                );
              }

              final list = snap.data ?? [];
              if (list.isEmpty) {
                return const SliverFillRemaining(
                  child: Center(child: Text('No matches found today.')),
                );
              }

              return SliverPadding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                sliver: SliverList.builder(
                  itemCount: list.length,
                  itemBuilder: (_, i) => FixtureCard(
                    fixture: list[i],
                    api: api,
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _header() => Padding(
        padding: const EdgeInsets.fromLTRB(18, 20, 18, 8),
        child: Row(
          children: [
            Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                color: accent,
                borderRadius: BorderRadius.circular(14),
              ),
              child: const Center(
                child: Text(
                  'HP',
                  style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Hit Predictor',
                    style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900),
                  ),
                  Text(
                    'Live football data',
                    style: TextStyle(color: Colors.white54, fontSize: 12),
                  ),
                ],
              ),
            ),
          ],
        ),
      );

  Widget _errorCard(String error) => Container(
        margin: const EdgeInsets.all(16),
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: card,
          borderRadius: BorderRadius.circular(18),
        ),
        child: Text(
          error,
          style: const TextStyle(color: Colors.white70, height: 1.5),
        ),
      );
}

class FixtureCard extends StatelessWidget {
  final Fixture fixture;
  final ApiFootball api;

  const FixtureCard({
    super.key,
    required this.fixture,
    required this.api,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: card,
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: const BorderSide(color: Colors.white10),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => MatchPage(fixture: fixture, api: api),
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      fixture.league,
                      style: const TextStyle(
                        color: accent,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  Text(
                    fixture.status,
                    style: const TextStyle(color: Colors.white54),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Text(
                '${fixture.home}  vs  ${fixture.away}',
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 13),
              const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.auto_awesome, color: accent, size: 17),
                  SizedBox(width: 6),
                  Text(
                    'Open analysis',
                    style: TextStyle(color: accent),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class MatchPage extends StatelessWidget {
  final Fixture fixture;
  final ApiFootball api;

  const MatchPage({
    super.key,
    required this.fixture,
    required this.api,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Match Analysis')),
      body: FutureBuilder<Prediction?>(
        future: api.prediction(fixture.id),
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snap.hasError) {
            return Center(child: Text(snap.error.toString()));
          }

          final p = snap.data;

          return ListView(
            padding: const EdgeInsets.all(18),
            children: [
              Text(
                fixture.league,
                style: const TextStyle(color: accent, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 18),
              Text(
                fixture.home,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
              ),
              const Padding(
                padding: EdgeInsets.all(7),
                child: Text(
                  'VS',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white38),
                ),
              ),
              Text(
                fixture.away,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 24),
              _box(
                'Predicted winner',
                Text(
                  p?.winner ?? 'Unavailable',
                  style: const TextStyle(
                    color: accent,
                    fontSize: 23,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
              _box(
                'Probabilities',
                Column(
                  children: [
                    _prob('Home', p?.homeWin ?? '-'),
                    _prob('Draw', p?.draw ?? '-'),
                    _prob('Away', p?.awayWin ?? '-'),
                  ],
                ),
              ),
              _box(
                'Model advice',
                Text(
                  p?.advice ?? 'No advice available',
                  style: const TextStyle(height: 1.5),
                ),
              ),
              const SizedBox(height: 6),
              const Text(
                'Predictions are statistical estimates, not guarantees.',
                style: TextStyle(color: Colors.white38, fontSize: 12),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _prob(String label, String value) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 7),
        child: Row(
          children: [
            Expanded(child: Text(label)),
            Text(
              value,
              style: const TextStyle(
                color: accent,
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
        ),
      );

  Widget _box(String title, Widget child) => Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(17),
        decoration: BoxDecoration(
          color: card,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Colors.white10),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(color: Colors.white54)),
            const SizedBox(height: 9),
            child,
          ],
        ),
      );
}

class ResultsPage extends StatelessWidget {
  const ResultsPage({super.key});

  Widget build(BuildContext context) => const Center(
        child: Text('Results will be populated from the API.'),
      );
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  Widget build(BuildContext context) => const Center(
        child: Text('Hit Predictor • Guest'),
      );
}
