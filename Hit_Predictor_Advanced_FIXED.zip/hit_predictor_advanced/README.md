# Hit Predictor Advanced

This version connects the Flutter app to API-Football.

## 1. Get an API key

Create an account on the official API-Football dashboard and copy your API key.

The free plan currently provides 100 requests/day and includes fixtures, predictions, statistics and odds; paid plans increase the request quota. Verify current pricing before production use.

## 2. Install packages

flutter pub get

## 3. Run

flutter run --dart-define=API_KEY=YOUR_API_KEY

## 4. Build APK

flutter build apk --release --dart-define=API_KEY=YOUR_API_KEY

APK:
build/app/outputs/flutter-apk/app-release.apk

## Important production architecture

For a public app, do not ship the API key inside the APK. Put the API key on your own backend and let the Flutter app call your backend. Add caching/rate limiting and a database for saved predictions.

The current app uses API-Football's fixtures endpoint for today's matches and its predictions endpoint for match prediction data.
